
import sys
import os

from __future__ import absolute_import
from __future__ import division
from __future__ import print_function
# from __future__ import unicode_literals
import numpy as np
from PIL import Image
import time
import argparse
import pyflow

import shutil

import cv2
import numpy as np

from tqdm import tqdm

# Flow Options:
alpha = 0.012
ratio = 0.75
minWidth = 20
nOuterFPIterations = 7
nInnerFPIterations = 1
nSORIterations = 30
colType = 0  # 0 or default:RGB, 1:GRAY (but pass gray image with shape (h,w,1))


if __name__ == '__main__':
    if not len(sys.argv) == 3:
        print('Falta la ruta de los archivos')
        sys.exit(2)
    else:
        video_dir = sys.argv[1]
        dest_dir = sys.argv[2]

        pbar_video_dir = tqdm(total=len(os.listdir(video_dir)))
        pbar_video_dir.set_description("\nCreando frames de flujo optico de: %s\n" % (video_dir))

        #por cada categoría
        for dir_name in os.listdir(video_dir):
            pbar_video_dir.update(1)
            
            if not os.path.exists(os.path.join(dest_dir,dir_name)):
                '''Creo el directorio de la categoría'''
                os.makedirs(os.path.join(dest_dir,dir_name))

                print("\nDirectorio creado:\n\t", os.path.join(dest_dir,dir_name))

            #por cada muestra en la categoría
            for video_dir_name in os.listdir(os.path.join(video_dir,dir_name)):
                
                dest_video_cat_dir = os.path.join(dest_dir,dir_name,video_dir_name)
                if not os.path.exists(dest_video_cat_dir):
                    '''Creo el directorio'''
                    os.makedirs(dest_video_cat_dir)
                    
                    print("\nDirectorio creado:\n\t", dest_video_cat_dir)
               
                source_path = os.path.join(video_dir, dir_name, video_dir_name)
                dest_path = dest_video_cat_dir#os.path.join(dest_video_cat_dir, video_dir_name)

                #print('source_path: ', source_path)
                #print('dest_path: ', dest_path)

                if os.path.exists(dest_path):
                    #debo hacerlo un archivo a la vez
                    i = 0

                    prvs = None
                    hsv = None

                    for video_frame in os.listdir(source_path):
                        source_path_file = os.path.join(source_path, video_frame)
                        dest_path_file = os.path.join(dest_path, video_frame)

                        print("\nProcessing: ", source_path_file)

                        ''' OPTICAL FLOW '''

												frame = np.array(Image.open(source_path_file))

                        if (frame.all() == None):
                            print("File not found: ", source_path_file)
                            break

                        #El primer frame será el prev frame
                        if (i == 0):
                            im1 = frame
                            
                        else:
		                        im2 = frame
		                        
														im1 = im1.astype(float) / 255.
														im2 = im2.astype(float) / 255.

														u, v, im2W = pyflow.coarse2fine_flow(
																im1, im2, alpha, ratio, minWidth, nOuterFPIterations, nInnerFPIterations,
																nSORIterations, colType)
														e = time.time()
														#print('Time Taken: %.2f seconds for image of size (%d, %d, %d)' % (
														#    e - s, im1.shape[0], im1.shape[1], im1.shape[2]))
														flow = np.concatenate((u[..., None], v[..., None]), axis=2)

														#np.save('examples/outFlow.npy', flow)

														hsv = np.zeros(im1.shape, dtype=np.uint8)
														hsv[:, :, 0] = 255
														hsv[:, :, 1] = 255
														mag, ang = cv2.cartToPolar(flow[..., 0], flow[..., 1])
														hsv[..., 0] = ang * 180 / np.pi / 2
														hsv[..., 2] = cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX)
														rgb = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
														
														cv2.imwrite(dest_path_file, rgb)
														#cv2.imwrite('examples/outFlow_new.png', rgb)
														#cv2.imwrite('examples/car2Warped_new.jpg', im2W[:, :, ::-1] * 255)
                            
                            im1 = im2

                        i = i + 1
        pbar_video_dir.close()

